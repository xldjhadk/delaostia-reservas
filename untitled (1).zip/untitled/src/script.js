// CONFIG DELAOSTIA
const restaurantConfig = {
  nombre: 'DELAOSTIA',
  horarioApertura: '20:30',
  horarioCierre: '23:00',
  diasAbiertos: ['jueves', 'viernes', 'sabado', 'domingo'],
  duracionReserva: (comensales) => comensales <= 5 ? 75 : 90 // minutos
};

// MESAS - PLANO REAL
const mesas = [
  // ZONA BARRA
  {id:'Barra1', nombre:'Barra 1', zona:'Barra', x:120, y:80, w:100, h:60, capacity:3, tipo:'barra'},
  {id:'Barra2', nombre:'Barra 2', zona:'Barra', x:240, y:80, w:100, h:60, capacity:3, tipo:'barra'},
  {id:'Barra4', nombre:'Barra 4', zona:'Barra', x:360, y:80, w:120, h:60, capacity:4, tipo:'barra'},
  
  // ZONA PRINCIPAL
  {id:'MesaAlta', nombre:'Mesa Alta', zona:'Principal', x:1050, y:50, w:120, h:80, capacity:4, tipo:'mesa'},
  {id:'Mesa1', nombre:'Mesa 1', zona:'Principal', x:1050, y:180, w:100, h:80, capacity:3, tipo:'mesa'},
  {id:'LaMesita', nombre:'La mesita', zona:'Baños', x:200, y:350, w:100, h:100, capacity:6, tipo:'mesa'},
  {id:'Mesa5', nombre:'Mesa 5', zona:'Principal', x:500, y:350, w:110, h:90, capacity:4, tipo:'mesa'},
  {id:'Mesa3', nombre:'Mesa 3', zona:'Principal', x:700, y:500, w:120, h:80, capacity:5, acoplabledeCon:['MesaVentana'], tipo:'mesa'},
  {id:'MesaVentana', nombre:'Mesa ventana', zona:'Principal', x:840, y:500, w:120, h:80, capacity:5, acoplablecon:['Mesa3'], tipo:'mesa'},
  
  // ZONA BAÑOS
  {id:'Aux', nombre:'Aux', zona:'Baños', x:20, y:80, w:90, h:60, capacity:4, tipo:'mesa'},
  {id:'Mesa7', nombre:'Mesa 7', zona:'Baños', x:80, y:480, w:140, h:100, capacity:4, acoplablecon:['Mesa6'], tipo:'mesa'},
  {id:'Mesa6', nombre:'Mesa 6', zona:'Baños', x:240, y:480, w:140, h:100, capacity:5, acoplablecon:['Mesa7'], tipo:'mesa'}
];

let reservasData = {};
let selectedTableId = null;

// LOGIN
const correctAnswers = ['luna','Luna','LUNA'];
document.getElementById('login-form').addEventListener('submit',(e)=>{
  e.preventDefault();
  const answer = document.getElementById('login-answer').value.trim();
  document.getElementById('login-error').classList.add('hidden');
  document.getElementById('login-success').classList.add('hidden');
  if(correctAnswers.includes(answer)){
    document.getElementById('login-success').classList.remove('hidden');
    setTimeout(()=>{
      document.getElementById('login-screen').classList.add('hidden');
      document.getElementById('main-app').classList.remove('hidden');
      initApp();
    },800);
  }else{
    document.getElementById('login-error').textContent='❌ Respuesta incorrecta';
    document.getElementById('login-error').classList.remove('hidden');
    document.getElementById('login-answer').value='';
  }
});

// INIT
function initApp(){
  renderFloorPlan();
  loadReservations();
  setupEventListeners();
  updateStats();
}

// RENDER FLOOR PLAN
function renderFloorPlan(){
  const inner = document.getElementById('floor-plan-inner');
  inner.innerHTML = '';
  mesas.forEach(mesa=>{
    const div = document.createElement('div');
    div.className = 'plan-item table';
    div.style.left = mesa.x+'px';
    div.style.top = mesa.y+'px';
    div.style.width = mesa.w+'px';
    div.style.height = mesa.h+'px';
    div.dataset.tableId = mesa.id;
    div.innerHTML = `<strong>${mesa.nombre}</strong><small>¶ ${mesa.capacity}</small>`;
    div.addEventListener('click',()=>selectTable(mesa.id, mesa));
    updateTableStatus(div, mesa.id);
    inner.appendChild(div);
  });
}

// SELECT TABLE
function selectTable(tableId, config){
  selectedTableId = tableId;
  document.querySelectorAll('.table').forEach(t=>t.classList.remove('selected'));
  document.querySelector(`[data-table-id="${tableId}"]`).classList.add('selected');
  showTableDetails(tableId, config);
}

// SHOW DETAILS
function showTableDetails(tableId, config){
  const reserva = reservasData[tableId];
  const details = document.getElementById('details-content');
  const noSel = document.getElementById('no-selection');
  const info = details.querySelector('.details-info');
  
  noSel.classList.add('hidden');
  details.classList.remove('hidden');
  document.getElementById('details-title').textContent = config.nombre;
  
  let duracion = restaurantConfig.duracionReserva(reserva?.comensales || 1);
  let html = `
    <div class="detail-item"><div class="detail-label">Zona</div><div class="detail-value">${config.zona}</div></div>
    <div class="detail-item"><div class="detail-label">Capacidad</div><div class="detail-value">¶ ${config.capacity}</div></div>
    ${reserva && reserva.nombre ? `<div class="detail-item"><div class="detail-label">Reservado por</div><div class="detail-value">${reserva.nombre}</div></div>` : ''}
    ${reserva && reserva.comensales ? `<div class="detail-item"><div class="detail-label">Comensales</div><div class="detail-value">${reserva.comensales} personas</div></div>` : ''}
    ${reserva && reserva.desde ? `<div class="detail-item"><div class="detail-label">Horario</div><div class="detail-value">${reserva.desde} - ${reserva.hasta} (${duracion}min)</div></div>` : '<div class="detail-item"><div class="detail-label">Estado</div><div class="detail-value">🟢 Disponible</div></div>'}
  `;
  info.innerHTML = html;
  const btn = document.createElement('button');
  btn.className = 'btn-primary';
  btn.style.width = '100%';
  btn.style.marginTop = '1rem';
  btn.textContent = reserva && reserva.nombre ? '📋 Editar' : '➕ Crear Reserva';
  btn.onclick = () => openModal(tableId);
  info.innerHTML += btn.outerHTML;
}
// STATUS
function updateTableStatus(tableEl, tableId){
  const reserva = reservasData[tableId];
  tableEl.classList.remove('status-available','status-full','status-pending');
  if(!reserva || !reserva.nombre) tableEl.classList.add('status-available');
  else{
    const now = new Date();
    const h = String(now.getHours()).padStart(2,'0');
    const m = String(now.getMinutes()).padStart(2,'0');
    const currentTime = h + ':' + m;
    if(currentTime >= reserva.desde && currentTime <= reserva.hasta) tableEl.classList.add('status-full');
    else tableEl.classList.add('status-pending');
  }
}

// LOAD
function loadReservations(){
  reservasData = JSON.parse(localStorage.getItem('reservas_delaostia')) || {};
  updateAllTables();
  updateStats();
}

function updateAllTables(){
  document.querySelectorAll('.table').forEach(tableEl=>{
    const tableId = tableEl.dataset.tableId;
    updateTableStatus(tableEl, tableId);
  });
}

// STATS
function updateStats(){
  let occupied = 0, totalGuests = 0;
  mesas.forEach(m=>{
    if(reservasData[m.id] && reservasData[m.id].nombre){
      occupied++;
      totalGuests += parseInt(reservasData[m.id].comensales) || 0;
    }
  });
  document.getElementById('stat-mesas-ocupadas').textContent = occupied;
  document.getElementById('stat-comensales').textContent = totalGuests;
}

// MODAL
function openModal(tableId){
  const config = mesas.find(t=>t.id===tableId);
  const reserva = reservasData[tableId] || {};
  document.getElementById('modalMesaId').value = tableId;
  document.getElementById('modalMesaName').value = config.nombre;
  document.getElementById('modalCapacidad').value = config.capacity;
  document.getElementById('modalNombre').value = reserva.nombre || '';
  document.getElementById('modalComensales').value = reserva.comensales || 2;
  document.getElementById('modalDesde').value = reserva.desde || '20:30';
  document.getElementById('modalHasta').value = reserva.hasta || '21:45';
  document.getElementById('modalNotas').value = reserva.notas || '';
  document.getElementById('modalReserva').classList.add('active');
}

function closeModal(){
  document.getElementById('modalReserva').classList.remove('active');
}

function saveReservation(){
  const tableId = document.getElementById('modalMesaId').value;
  const nombre = document.getElementById('modalNombre').value.trim();
  const comensales = parseInt(document.getElementById('modalComensales').value);
  const desde = document.getElementById('modalDesde').value;
  const hasta = document.getElementById('modalHasta').value;
  const config = mesas.find(t=>t.id===tableId);
  
  if(!nombre || !desde || !hasta){alert('⚠️ Campos requeridos');return;}
  if(comensales > config.capacity){alert('⚠️ Excede capacidad');return;}
  
  const duracion = restaurantConfig.duracionReserva(comensales);
  reservasData[tableId] = {nombre,comensales,desde,hasta,duracion};
  localStorage.setItem('reservas_delaostia', JSON.stringify(reservasData));
  loadReservations();
  closeModal();
  alert('✅ Reserva guardada');
}

function deleteReservation(){
  const tableId = document.getElementById('modalMesaId').value;
  if(confirm('⚠️ ¿Eliminar reserva?')){
    delete reservasData[tableId];
    localStorage.setItem('reservas_delaostia', JSON.stringify(reservasData));
    loadReservations();
    closeModal();
  }
}

// EVENTS
function setupEventListeners(){
  document.getElementById('btnCrearReserva').addEventListener('click', saveReservation);
  document.getElementById('btn-eliminar').addEventListener('click', deleteReservation);
  document.getElementById('btn-cancelar-modal').addEventListener('click', closeModal);
  document.getElementById('btn-close-modal').addEventListener('click', closeModal);
  document.getElementById('btn-logout').addEventListener('click', ()=>{
    document.getElementById('login-screen').classList.remove('hidden');
    document.getElementById('main-app').classList.add('hidden');
    document.getElementById('login-answer').value='';
  });
  document.getElementById('modalReserva').addEventListener('click',(e)=>{
    if(e.target.id === 'modalReserva') closeModal();
  });
  document.getElementById('btn-refresh').addEventListener('click', loadReservations);
}